<?php
/**
 * Description of Code Completion file for Yii Framework with NetBeans.
 *
 * This is file for code completion of yii framework.
 * Please put this to your nbproject folder. (e.g. yourproject/nbproject/code_completion.php)
 *
 * Yii::app()->[Ctrl + Spase]
 * CWebApplication methods and fields are added in the popup list.
 *
 * @author junichi11
 * @link https://gist.github.com/4393875
 */
class Yii extends YiiBase {

	/**
	 * @return CWebApplication
	 */
	public static function app() {}

}
